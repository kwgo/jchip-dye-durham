#!/bin/bash

java -Dlog4j.configuration=config/log4j2.properties -jar lib/datapull.jar config/datapull.gcsra.ini