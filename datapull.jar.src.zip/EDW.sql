with vdns as (
VDN_PARAM
), calls as (
SELECT dialed_num, CallAnsThreshold, AnsThreshPct, max(SEGSTOP_DT_TM) as SEGSTOP_DT_TM, CALLID
        , sum(case when disposition = 2 then 1 else 0 end) Answered
        , sum(case when disposition = 2 then DISPTIME else 0 end) AnsweredWaitSec
        , sum(case when disposition = 2 then TALKTIME else 0 end) TalkTime
        , sum(case when disposition = 3 then 1 else 0 end) Abandoned
        , sum(case when disposition = 3 then DISPTIME else 0 end) AbnWaitSec
        , sum(ANSHOLDTIME) AnsHoldTime
FROM CCART_VIEWS.VAVAYA_CALL_RECORD
join vdns v
on  dialed_num = v.Vdn and SEGSTOP_DT_TM > StartTime and segstop_dt_tm < trunc(current_date, 'dd')
where disposition in (2,3)
group by  dialed_num,CallAnsThreshold, AnsThreshPct, CALLID
)
select  dialed_num,trunc(SEGSTOP_DT_TM, 'DD') ReportPeriod, to_char(SEGSTOP_DT_TM,'HH') ReportedHour , count(DISTINCT CALLID) as Incoming, sum(AnsweredWaitSec) as AnsweredWaitSec,
    sum(Answered) as Answered, sum (case when AnsweredWaitSec > CallAnsThreshold then 1 else 0 end) as AnsweredPostThreshold,
    sum(Abandoned) as Abandoned, sum (case when AbnWaitSec > CallAnsThreshold then 1 else 0 end) as AbandonedPostThreshold,
    sum(AbnWaitSec) as AbandonedWaitSec, max(AnsweredWaitSec) MaxWaitSec, sum(TalkTime) TalkSec
from calls
group by  dialed_num,ReportPeriod,ReportedHour
order by  dialed_num,ReportPeriod,ReportedHour