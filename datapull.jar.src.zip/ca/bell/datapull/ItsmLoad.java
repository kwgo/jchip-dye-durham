/*    */ package ca.bell.datapull;
/*    */ 
/*    */ import ca.bell.datapull.db.DbConn_TeraData;
/*    */ import ca.bell.datapull.db.VdnRec;
/*    */ import ca.bell.datapull.exception.DbException;
/*    */ import ca.bell.datapull.remedy.ItsmBroker;
/*    */ import ca.bell.datapull.util.Version;
/*    */ import com.bmc.arsys.api.ARException;
/*    */ import java.io.File;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ItsmLoad
/*    */ {
/* 20 */   private static Logger logger = Logger.getLogger(ItsmLoad.class);
/*    */   
/*    */   public static void main(String[] args) {
/* 23 */     if (args.length < 1) {
/* 24 */       usage();
/*    */     }
/*    */     
/* 27 */     String iniPath = args[0];
/* 28 */     Context ctx = Context.init(iniPath);
/*    */     
/* 30 */     ItsmBroker broker = new ItsmBroker();
/* 31 */     List<VdnRec> vdnRecs = new ArrayList<>();
/* 32 */     DbConn_TeraData dbConn_TeraData = ctx.getDbConn_TeraData();
/*    */     try {
/* 34 */       String sql = broker.populateEDWSql(ctx.getEdwSQL());
/* 35 */       logger.debug("Generated Final EDW SQL is : " + sql);
/* 36 */       vdnRecs = dbConn_TeraData.getVdnRecs(sql);
/* 37 */     } catch (ARException x) {
/* 38 */       logger.error("Broker exception : " + x.getMessage());
/* 39 */     } catch (DbException x) {
/* 40 */       logger.error("Database exception : " + x.getMessage());
/*    */     } 
/*    */     
/* 43 */     String linkValue = String.format("%2.8s.%d", new Object[] { "GCSRA", Long.valueOf(System.currentTimeMillis()) });
/*    */     
/* 45 */     List<String> errs = broker.upload(linkValue, vdnRecs);
/*    */     
/* 47 */     if (errs.size() > 0) {
/* 48 */       logger.error("On [" + linkValue + "], " + errs.size() + " Remedy errors:\n" + String.join("\n", (Iterable)errs));
/*    */     }
/*    */     
/* 51 */     logger.info("Success");
/* 52 */     System.exit(0);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   private static void usage() {
/* 58 */     String jar = (new File(ItsmLoad.class.getProtectionDomain().getCodeSource().getLocation().getPath())).getName();
/*    */     
/* 60 */     System.out.println("Usage:");
/* 61 */     System.out.println("    java -jar " + jar + " <ini-file>");
/* 62 */     System.out.println();
/* 63 */     System.out.println("with:");
/* 64 */     System.out.println("    <ini-file> - path to configuration file,");
/* 65 */     System.out.println();
/* 66 */     System.out.println("E.g.,");
/* 67 */     System.out.println("    java -jar " + jar + " config/datapull.ini");
/* 68 */     System.out.println();
/* 69 */     System.out.println(Version.getVersion());
/* 70 */     System.exit(0);
/*    */   }
/*    */ }


/* Location:              C:\kwgo\software\datapull\datapull_lib\lib\datapull.jar!\ca\bell\datapull\ItsmLoad.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */