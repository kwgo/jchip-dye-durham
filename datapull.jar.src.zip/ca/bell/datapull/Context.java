/*     */ package ca.bell.datapull;
/*     */ 
/*     */ import ca.bell.datapull.db.DbConn_TeraData;
/*     */ import ca.bell.datapull.exception.ConfigException;
/*     */ import ca.bell.datapull.exception.DbException;
/*     */ import ca.bell.datapull.remedy.schema.BulkLoadSchema;
/*     */ import ca.bell.datapull.util.DbShutdown_TeraData;
/*     */ import ca.bell.datapull.util.IniFile;
/*     */ import ca.bell.datapull.util.RemedyLogout;
/*     */ import com.bmc.arsys.api.ARException;
/*     */ import com.bmc.arsys.api.ARServerUser;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.InputStreamReader;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.apache.log4j.PropertyConfigurator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Context
/*     */ {
/*  26 */   private static Logger logger = Logger.getLogger(Context.class);
/*     */   
/*  28 */   private static Context theInstance = null;
/*     */   
/*  30 */   private ARServerUser arSession = null;
/*     */   
/*  32 */   private DbConn_TeraData dbConn_TeraData = null;
/*     */   
/*     */   private String edwSQL;
/*     */   
/*  36 */   private IniFile iniFile = null;
/*     */   
/*     */   private Context(String iniPath) throws ConfigException, ARException, DbException {
/*  39 */     this.arSession = new ARServerUser();
/*  40 */     this.iniFile = new IniFile(iniPath);
/*  41 */     PropertyConfigurator.configure(this.iniFile.getString(IniFile.IniToken.SECTION_LOG4J, IniFile.IniToken.CONFIG));
/*     */ 
/*     */     
/*  44 */     boolean isRemedyAvailable = (this.iniFile.getInteger(IniFile.IniToken.SECTION_REMEDY, IniFile.IniToken.CONNECT).intValue() == 1);
/*  45 */     String server = this.iniFile.getString(IniFile.IniToken.SECTION_REMEDY, IniFile.IniToken.SERVER);
/*  46 */     String user = this.iniFile.getString(IniFile.IniToken.SECTION_REMEDY, IniFile.IniToken.USER);
/*  47 */     String password = this.iniFile.getString(IniFile.IniToken.SECTION_REMEDY, IniFile.IniToken.PASSWORD);
/*  48 */     Integer port = this.iniFile.getInteger(IniFile.IniToken.SECTION_REMEDY, IniFile.IniToken.REMEDY_PORT);
/*     */     
/*  50 */     logger.debug("Parsed configuration file [" + iniPath + "]");
/*     */     
/*  52 */     if (isRemedyAvailable) {
/*  53 */       this.arSession.setServer(server);
/*  54 */       this.arSession.setUser(user);
/*  55 */       this.arSession.setPassword(password);
/*  56 */       this.arSession.setPort(port.intValue());
/*     */       
/*  58 */       this.arSession.login();
/*  59 */       logger.info("Remedy Login OK: user [" + user + "] at server [" + server + "]");
/*     */     } 
/*     */ 
/*     */     
/*  63 */     if (this.iniFile.getInteger(IniFile.IniToken.SECTION_DATABASE, IniFile.IniToken.CONNECT).intValue() == 1) {
/*  64 */       DbConn_TeraData.init(this.iniFile);
/*  65 */       this.dbConn_TeraData = DbConn_TeraData.getInstance();
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/*  70 */       BufferedReader br = new BufferedReader(new InputStreamReader(getClass().getClassLoader().getResourceAsStream("EDW.sql")));
/*  71 */       StringBuffer sb = new StringBuffer();
/*     */       String line;
/*  73 */       while ((line = br.readLine()) != null) {
/*  74 */         sb.append(line).append("\n");
/*     */       }
/*  76 */       br.close();
/*  77 */       this.edwSQL = sb.toString();
/*  78 */     } catch (Exception ex) {
/*  79 */       logger.error("Unable to find file EDW.sql , Error: " + ex.toString());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DbConn_TeraData getDbConn_TeraData() {
/*  91 */     return this.dbConn_TeraData;
/*     */   }
/*     */   
/*     */   public String getEdwSQL() {
/*  95 */     return this.edwSQL;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IniFile getIniFile() {
/* 104 */     return this.iniFile;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ARServerUser getSession() {
/* 113 */     return this.arSession;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Context getInstance() {
/* 123 */     if (theInstance == null) {
/* 124 */       throw new IllegalStateException("Context not initialized");
/*     */     }
/*     */     
/* 127 */     return theInstance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized Context init(String iniPath) {
/* 139 */     if (iniPath == null) {
/* 140 */       throw new IllegalArgumentException("iniPath must not be null");
/*     */     }
/*     */     
/* 143 */     if (theInstance == null) {
/*     */       try {
/* 145 */         theInstance = new Context(iniPath);
/*     */         
/* 147 */         if (theInstance.getIniFile().getInteger(IniFile.IniToken.SECTION_REMEDY, IniFile.IniToken.CONNECT).intValue() == 1) {
/* 148 */           RemedyLogout.onShutdownHook(theInstance.arSession);
/* 149 */           BulkLoadSchema.init();
/*     */         } 
/* 151 */         if (theInstance.getIniFile().getInteger(IniFile.IniToken.SECTION_DATABASE, IniFile.IniToken.CONNECT).intValue() == 1) {
/* 152 */           DbShutdown_TeraData.onShutdownHook(theInstance.dbConn_TeraData);
/*     */         }
/* 154 */       } catch (ConfigException|ARException|DbException x) {
/* 155 */         logger.error("Error processing data", x);
/* 156 */         System.exit(-1);
/*     */       } 
/*     */     }
/* 159 */     return theInstance;
/*     */   }
/*     */ }


/* Location:              C:\kwgo\software\datapull\datapull_lib\lib\datapull.jar!\ca\bell\datapull\Context.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */