/*    */ package ca.bell.datapull.remedy.value;
/*    */ 
/*    */ import ca.bell.datapull.exception.RemedyValueException;
/*    */ import com.bmc.arsys.api.Value;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IntegerValueFactory
/*    */   extends AbstractValueFactory
/*    */ {
/* 14 */   private static IntegerValueFactory theInstance = new IntegerValueFactory();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Value str2Value(String input) throws RemedyValueException {
/*    */     Integer integer;
/* 31 */     if (input == null || input.length() == 0) {
/* 32 */       return null;
/*    */     }
/*    */ 
/*    */     
/*    */     try {
/* 37 */       integer = Integer.valueOf(Integer.parseInt(input));
/* 38 */     } catch (NumberFormatException x) {
/* 39 */       throw new RemedyValueException("Value [" + input + "] must be 32-bit integer");
/*    */     } 
/*    */     
/* 42 */     return new Value(integer.intValue());
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static IntegerValueFactory getInstance() {
/* 52 */     return theInstance;
/*    */   }
/*    */ }


/* Location:              C:\kwgo\software\datapull\datapull_lib\lib\datapull.jar!\ca\bell\datapull\remedy\value\IntegerValueFactory.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */