/*    */ package ca.bell.datapull.remedy.value;
/*    */ 
/*    */ import ca.bell.datapull.exception.RemedyValueException;
/*    */ import com.bmc.arsys.api.Value;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NonValueFactory
/*    */   extends AbstractValueFactory
/*    */ {
/* 14 */   private static NonValueFactory theInstance = new NonValueFactory();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Value str2Value(String input) throws RemedyValueException {
/* 30 */     throw new RemedyValueException("Cannot generate Remedy form attachment value from String [" + input + "]");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static NonValueFactory getInstance() {
/* 40 */     return theInstance;
/*    */   }
/*    */ }


/* Location:              C:\kwgo\software\datapull\datapull_lib\lib\datapull.jar!\ca\bell\datapull\remedy\value\NonValueFactory.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */