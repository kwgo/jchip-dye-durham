/*    */ package ca.bell.datapull.remedy.value;
/*    */ 
/*    */ import ca.bell.datapull.exception.RemedyValueException;
/*    */ import com.bmc.arsys.api.Timestamp;
/*    */ import com.bmc.arsys.api.Value;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DateTimeValueFactory
/*    */   extends AbstractValueFactory
/*    */ {
/* 13 */   private static long MAX_EPOCH_SEC = 9999999999L;
/*    */   
/* 15 */   private static long MIN_EPOCH_SEC = 0L;
/*    */ 
/*    */   
/* 18 */   private static DateTimeValueFactory theInstance = new DateTimeValueFactory();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Value str2Value(String input) throws RemedyValueException {
/* 36 */     if (input == null || input.length() == 0) {
/* 37 */       return null;
/*    */     }
/*    */     
/* 40 */     Long epochSec = Long.valueOf(-1L);
/*    */     try {
/* 42 */       epochSec = Long.valueOf(Long.parseLong(input));
/* 43 */     } catch (NumberFormatException x) {
/* 44 */       throw new RemedyValueException("Value [" + input + "] must be EPOCH seconds");
/*    */     } 
/*    */     
/* 47 */     if (MIN_EPOCH_SEC > epochSec.longValue() || epochSec.longValue() > MAX_EPOCH_SEC) {
/* 48 */       throw new RemedyValueException("Value [" + input + "] must be EPOCH seconds");
/*    */     }
/*    */     
/* 51 */     return new Value(new Timestamp(epochSec.longValue()));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static DateTimeValueFactory getInstance() {
/* 61 */     return theInstance;
/*    */   }
/*    */ }


/* Location:              C:\kwgo\software\datapull\datapull_lib\lib\datapull.jar!\ca\bell\datapull\remedy\value\DateTimeValueFactory.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */