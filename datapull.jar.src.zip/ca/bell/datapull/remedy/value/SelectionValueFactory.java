/*    */ package ca.bell.datapull.remedy.value;
/*    */ 
/*    */ import ca.bell.datapull.exception.RemedyValueException;
/*    */ import com.bmc.arsys.api.Value;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SelectionValueFactory
/*    */   extends AbstractValueFactory
/*    */ {
/*    */   private Map<String, Integer> choices;
/*    */   private String fieldName;
/*    */   private String schema;
/*    */   
/*    */   public SelectionValueFactory(String schema, String fieldName) {
/* 31 */     this.schema = schema;
/* 32 */     this.fieldName = fieldName;
/* 33 */     this.choices = new HashMap<>();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String index2Label(Integer index) {
/* 47 */     if (index == null) {
/* 48 */       return null;
/*    */     }
/*    */     
/* 51 */     for (Map.Entry<String, Integer> kv : this.choices.entrySet()) {
/* 52 */       if (kv.getValue() == index) {
/* 53 */         return kv.getKey();
/*    */       }
/*    */     } 
/*    */     
/* 57 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void put(String label, Integer index) {
/* 69 */     if (label == null || index == null) {
/* 70 */       throw new IllegalArgumentException("label, index must not be null");
/*    */     }
/*    */     
/* 73 */     this.choices.put(label, index);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Value str2Value(String input) throws RemedyValueException {
/* 87 */     if (input == null) {
/* 88 */       return null;
/*    */     }
/*    */     
/* 91 */     Integer rv = this.choices.get(input);
/* 92 */     if (rv == null) {
/* 93 */       throw new RemedyValueException("Choice [" + input + "] not available for " + this.schema + " field [" + this.fieldName + "]");
/*    */     }
/*    */ 
/*    */     
/* 97 */     return new Value(rv.intValue());
/*    */   }
/*    */ }


/* Location:              C:\kwgo\software\datapull\datapull_lib\lib\datapull.jar!\ca\bell\datapull\remedy\value\SelectionValueFactory.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */