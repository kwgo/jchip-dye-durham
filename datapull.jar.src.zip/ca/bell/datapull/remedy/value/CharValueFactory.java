/*    */ package ca.bell.datapull.remedy.value;
/*    */ 
/*    */ import ca.bell.datapull.exception.RemedyValueException;
/*    */ import com.bmc.arsys.api.Value;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CharValueFactory
/*    */   extends AbstractValueFactory
/*    */ {
/*    */   private int maxLen;
/*    */   
/*    */   public CharValueFactory() {
/* 18 */     this(0);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public CharValueFactory(int maxLen) {
/* 28 */     this.maxLen = (maxLen < 0) ? 0 : maxLen;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Value str2Value(String input) throws RemedyValueException {
/* 45 */     if (input == null || input.length() == 0) {
/* 46 */       return null;
/*    */     }
/*    */     
/* 49 */     if (this.maxLen == 0) {
/* 50 */       return new Value(input);
/*    */     }
/*    */     
/* 53 */     if (input.length() > this.maxLen) {
/* 54 */       return new Value(input.substring(0, this.maxLen));
/*    */     }
/*    */     
/* 57 */     return new Value(input);
/*    */   }
/*    */ }


/* Location:              C:\kwgo\software\datapull\datapull_lib\lib\datapull.jar!\ca\bell\datapull\remedy\value\CharValueFactory.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */