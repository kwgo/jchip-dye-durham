package ca.bell.datapull.remedy.value;

import ca.bell.datapull.exception.RemedyValueException;
import com.bmc.arsys.api.Value;

public abstract class AbstractValueFactory {
  public abstract Value str2Value(String paramString) throws RemedyValueException;
}


/* Location:              C:\kwgo\software\datapull\datapull_lib\lib\datapull.jar!\ca\bell\datapull\remedy\value\AbstractValueFactory.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */