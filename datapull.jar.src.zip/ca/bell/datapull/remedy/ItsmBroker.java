/*     */ package ca.bell.datapull.remedy;
/*     */ 
/*     */ import ca.bell.datapull.Context;
/*     */ import ca.bell.datapull.db.VdnRec;
/*     */ import ca.bell.datapull.exception.RemedyValueException;
/*     */ import ca.bell.datapull.remedy.schema.BulkLoadSchema;
/*     */ import com.bmc.arsys.api.ARException;
/*     */ import com.bmc.arsys.api.ARServerUser;
/*     */ import com.bmc.arsys.api.ArithmeticOrRelationalOperand;
/*     */ import com.bmc.arsys.api.Entry;
/*     */ import com.bmc.arsys.api.EntryValueList;
/*     */ import com.bmc.arsys.api.FieldOperandInfo;
/*     */ import com.bmc.arsys.api.FunctionCode;
/*     */ import com.bmc.arsys.api.FunctionOperandInfo;
/*     */ import com.bmc.arsys.api.IQuerySource;
/*     */ import com.bmc.arsys.api.QualifierInfo;
/*     */ import com.bmc.arsys.api.QuerySourceForm;
/*     */ import com.bmc.arsys.api.RegularComplexQuery;
/*     */ import com.bmc.arsys.api.RelationalOperationInfo;
/*     */ import com.bmc.arsys.api.Value;
/*     */ import java.text.DateFormat;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.time.LocalDateTime;
/*     */ import java.time.ZoneId;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.stream.Collectors;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ItsmBroker
/*     */ {
/*     */   public static final String NAME_FORM_CONFIGURATION_DATA = "DOP:ConfigurationData-ConfigurationData-join";
/*     */   public static final int ID_FIELD_STATUS = 536870923;
/*     */   public static final int ID_STATUS_ACTIVE = 1;
/*  47 */   public static final int[] IDS_FIELDS_CONFIG = new int[] { 600000002, 600000003, 600000000, 600000001 };
/*     */   
/*     */   public static final String pattern = "yyyy-MM-dd";
/*     */   
/*  51 */   protected static final DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
/*     */   
/*  53 */   private static Logger logger = Logger.getLogger(ItsmBroker.class);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  61 */   private ARServerUser session = Context.getInstance().getSession();
/*     */ 
/*     */   
/*     */   public String populateEDWSql(String sql) throws ARException {
/*  65 */     List<Entry> entries = getConfigData();
/*     */     
/*  67 */     StringBuffer sb = new StringBuffer();
/*     */     
/*  69 */     Map<String, Map<String, String>> thresholdsPerVdn = (Map<String, Map<String, String>>)entries.stream().collect(Collectors.groupingBy(x -> ((Value)x.get(Integer.valueOf(600000003))).getValue().toString(), 
/*  70 */           Collectors.toMap(x -> ((Value)x.get(Integer.valueOf(600000000))).getValue().toString(), x -> ((Value)x.get(Integer.valueOf(600000001))).getValue().toString(), (e1, e2) -> e1)));
/*     */     
/*  72 */     logger.info("VDN thresholds");
/*  73 */     for (Map.Entry<String, Map<String, String>> e : thresholdsPerVdn.entrySet()) {
/*  74 */       logger.info((String)e.getKey() + ":" + (String)e.getKey());
/*     */     }
/*     */     
/*  77 */     Map<String, String> dates = getMaxPullDate((List<String>)thresholdsPerVdn.keySet().stream().collect(Collectors.toList()));
/*     */     
/*  79 */     Iterator<String> iterator = thresholdsPerVdn.keySet().iterator();
/*  80 */     String firstKey = iterator.next();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  95 */     sb.append("select '" + firstKey + "' as Vdn,  " + (String)((Map)thresholdsPerVdn
/*  96 */         .get(firstKey)).getOrDefault("CallAnswerThreshold", "20") + " as CallAnsThreshold, " + (String)((Map)thresholdsPerVdn
/*  97 */         .get(firstKey)).getOrDefault("CallAnswerSLTPercent", "80") + " as AnsThreshPct, to_date('" + (String)dates
/*  98 */         .getOrDefault(firstKey, "2022-01-01") + "', 'YYYY-MM-DD') StartTime from (select 1 as \"Dummy\") as \"DUAL\"")
/*  99 */       .append("\n");
/* 100 */     while (iterator.hasNext()) {
/* 101 */       String key = iterator.next();
/* 102 */       sb.append("union select  '" + key + "', " + (String)((Map)thresholdsPerVdn
/* 103 */           .get(key)).getOrDefault("CallAnswerThreshold", "20") + ", " + (String)((Map)thresholdsPerVdn
/* 104 */           .get(key)).getOrDefault("CallAnswerSLTPercent", "80") + ", to_date('" + (String)dates
/* 105 */           .getOrDefault(key, "2022-01-01") + "', 'YYYY-MM-DD') from (select 1 as \"Dummy\") as \"DUAL\"")
/* 106 */         .append("\n");
/*     */     } 
/*     */ 
/*     */     
/* 110 */     String finalSQL = sql.replaceAll("VDN_PARAM", sb.toString());
/* 111 */     return finalSQL;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List<String> upload(String linkValue, List<VdnRec> vdnRecs) {
/* 126 */     if (vdnRecs == null) {
/* 127 */       throw new IllegalArgumentException("vdnRecs must not be null");
/*     */     }
/*     */     
/* 130 */     int uploaded = 0;
/* 131 */     List<String> rv = new ArrayList<>();
/*     */     
/* 133 */     for (VdnRec vdnRec : vdnRecs) {
/* 134 */       LocalDateTime ldh = vdnRec.getLocalDateHour();
/* 135 */       Entry entry = new Entry();
/*     */       try {
/* 137 */         entry.put(BulkLoadSchema.SemanticField.LINK.getId(), BulkLoadSchema.SemanticField.LINK
/* 138 */             .toValue(linkValue));
/* 139 */         entry.put(BulkLoadSchema.SemanticField.STATUS.getId(), BulkLoadSchema.SemanticField.STATUS
/* 140 */             .toValue(BulkLoadSchema.Status.ACTIVE.toString()));
/* 141 */         entry.put(BulkLoadSchema.SemanticField.DATE.getId(), BulkLoadSchema.SemanticField.DATE.toValue(
/* 142 */               Long.toString(ldh.toLocalDate().atStartOfDay(ZoneId.systemDefault()).toEpochSecond())));
/* 143 */         entry.put(BulkLoadSchema.SemanticField.HOUR.getId(), BulkLoadSchema.SemanticField.HOUR
/* 144 */             .toValue(Integer.toString(vdnRec.getHour())));
/* 145 */         entry.put(BulkLoadSchema.SemanticField.VDN.getId(), BulkLoadSchema.SemanticField.VDN
/* 146 */             .toValue(vdnRec.getVdn()));
/* 147 */         entry.put(BulkLoadSchema.SemanticField.INCOMING.getId(), BulkLoadSchema.SemanticField.INCOMING
/* 148 */             .toValue(Integer.toString(vdnRec.getIncoming())));
/* 149 */         entry.put(BulkLoadSchema.SemanticField.ANSWERED.getId(), BulkLoadSchema.SemanticField.ANSWERED
/* 150 */             .toValue(Integer.toString(vdnRec.getAnswered())));
/* 151 */         entry.put(BulkLoadSchema.SemanticField.ABANDONED.getId(), BulkLoadSchema.SemanticField.ABANDONED
/* 152 */             .toValue(Integer.toString(vdnRec.getAbandoned())));
/* 153 */         entry.put(BulkLoadSchema.SemanticField.ANSWERED_POST_THRESHOLD.getId(), BulkLoadSchema.SemanticField.ANSWERED_POST_THRESHOLD
/*     */             
/* 155 */             .toValue(Integer.toString(vdnRec.getAnsweredPostThreshold())));
/* 156 */         entry.put(BulkLoadSchema.SemanticField.ABANDONED_POST_THRESHOLD.getId(), BulkLoadSchema.SemanticField.ABANDONED_POST_THRESHOLD
/*     */             
/* 158 */             .toValue(Integer.toString(vdnRec.getAbandonedPostThreshold())));
/* 159 */         entry.put(BulkLoadSchema.SemanticField.DROPPED.getId(), BulkLoadSchema.SemanticField.DROPPED
/* 160 */             .toValue(Integer.toString(vdnRec.getDropped())));
/* 161 */         entry.put(BulkLoadSchema.SemanticField.ANSWER_WAIT_SEC.getId(), BulkLoadSchema.SemanticField.ANSWER_WAIT_SEC
/*     */             
/* 163 */             .toValue(Integer.toString(vdnRec.getAnswerWaitSec())));
/* 164 */         entry.put(BulkLoadSchema.SemanticField.MAX_WAIT_SEC.getId(), BulkLoadSchema.SemanticField.MAX_WAIT_SEC
/* 165 */             .toValue(Integer.toString(vdnRec.getMaxWaitSec())));
/* 166 */         entry.put(BulkLoadSchema.SemanticField.TALK_SEC.getId(), BulkLoadSchema.SemanticField.TALK_SEC
/* 167 */             .toValue(Integer.toString(vdnRec.getTalkSec())));
/* 168 */         entry.put(BulkLoadSchema.SemanticField.ABANDONED_WAIT_SEC.getId(), BulkLoadSchema.SemanticField.ABANDONED_WAIT_SEC
/*     */             
/* 170 */             .toValue(Integer.toString(vdnRec.getAbandonedWaitSec())));
/* 171 */         entry.put(BulkLoadSchema.SemanticField.ANSWERED_HOLD_PAST_THRESHOLD.getId(), BulkLoadSchema.SemanticField.ANSWERED_HOLD_PAST_THRESHOLD
/*     */             
/* 173 */             .toValue(Integer.toString(vdnRec.getAnsHoldPastThreshold())));
/*     */         
/* 175 */         String entryId = this.session.createEntry(BulkLoadSchema.getName(), entry);
/* 176 */         uploaded++;
/* 177 */         logger.info("Created Remedy entry [" + entryId + "] for date+hour [" + vdnRec.getLocalDateHour() + "] ] on VDN [" + vdnRec
/* 178 */             .getVdn() + "]");
/* 179 */       } catch (RemedyValueException x) {
/*     */         
/* 181 */         logger.error("Unfathomable error on Remedy value creation: [" + x.getMessage() + "], skipping entry for date+hour [" + ldh + "] on VDN [" + vdnRec
/* 182 */             .getVdn() + "]");
/* 183 */       } catch (ARException x) {
/* 184 */         logger.error("Remedy exception on upload, skipping date+hour [" + ldh + "] on VDN [" + vdnRec.getVdn() + "]: " + x
/* 185 */             .getMessage());
/*     */       } 
/*     */     } 
/*     */     
/* 189 */     logger.info("Created [" + uploaded + "] entries on Remedy with link value [" + linkValue + "]");
/*     */     
/* 191 */     return rv;
/*     */   }
/*     */ 
/*     */   
/*     */   private List<Entry> getConfigData() throws ARException {
/* 196 */     List<Entry> entries = null;
/*     */     
/* 198 */     QualifierInfo qualifier = this.session.parseQualification("DOP:ConfigurationData-ConfigurationData-join", "'536870923' = 1");
/*     */ 
/*     */     
/* 201 */     logger.info("before calling ITSM DOP:ConfigurationData-ConfigurationData-join");
/* 202 */     entries = this.session.getListEntryObjects("DOP:ConfigurationData-ConfigurationData-join", qualifier, 0, 0, null, IDS_FIELDS_CONFIG, false, null);
/*     */ 
/*     */     
/* 205 */     logger.debug("Config data returned from DOP:ConfigurationData-ConfigurationData-join : " + entries.toString());
/*     */     
/* 207 */     return entries;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private Map<String, String> getMaxPullDate(List<String> vdns) throws ARException {
/* 213 */     QuerySourceForm source = new QuerySourceForm("DOP:AvayaCallData");
/*     */     
/* 215 */     FieldOperandInfo pullDate = new FieldOperandInfo(689001012, (IQuerySource)source);
/*     */     
/* 217 */     FieldOperandInfo vdnField = new FieldOperandInfo(689001000, (IQuerySource)source);
/* 218 */     ArithmeticOrRelationalOperand vdnOperand = new ArithmeticOrRelationalOperand(vdnField);
/* 219 */     ArithmeticOrRelationalOperand pullDateOperand = new ArithmeticOrRelationalOperand(pullDate);
/* 220 */     FunctionOperandInfo maxPullDateInfo = new FunctionOperandInfo(FunctionCode.Max, Arrays.asList(new ArithmeticOrRelationalOperand[] { pullDateOperand }));
/* 221 */     ArithmeticOrRelationalOperand maxPullDateOperand = new ArithmeticOrRelationalOperand(maxPullDateInfo);
/*     */     
/* 223 */     QualifierInfo where = null;
/* 224 */     for (String vdn : vdns) {
/* 225 */       ArithmeticOrRelationalOperand vdnValue = new ArithmeticOrRelationalOperand(new Value(vdn));
/* 226 */       RelationalOperationInfo vdnEqVal = new RelationalOperationInfo(1, vdnOperand, vdnValue);
/*     */       
/* 228 */       if (where == null) {
/* 229 */         where = new QualifierInfo(vdnEqVal); continue;
/*     */       } 
/* 231 */       where = new QualifierInfo(2, where, new QualifierInfo(vdnEqVal));
/*     */     } 
/*     */ 
/*     */     
/* 235 */     RegularComplexQuery query = new RegularComplexQuery();
/* 236 */     query.setSelectionList(Arrays.asList(new ArithmeticOrRelationalOperand[] { vdnOperand, maxPullDateOperand }));
/* 237 */     query.setFromSources(Arrays.asList(new IQuerySource[] { (IQuerySource)source }));
/* 238 */     query.setQualifier(where);
/* 239 */     query.setGroupBy(Arrays.asList(new ArithmeticOrRelationalOperand[] { vdnOperand }));
/*     */     
/* 241 */     List<EntryValueList> values = this.session.getListValuesFromMultiSchemaEntries(query, 0, 100, false, false, null);
/*     */ 
/*     */     
/* 244 */     logger.info("VDN Max Dates");
/* 245 */     for (EntryValueList value : values) {
/* 246 */       logger.info("" + value.get(vdnOperand) + ":" + value.get(vdnOperand));
/*     */     }
/*     */ 
/*     */     
/* 250 */     Map<String, String> maxPulldatesPerVdn = (Map<String, String>)values.stream().collect(Collectors.toMap(x -> x.get(vdnOperand).toString(), x -> df.format(new Date(x.get(maxPullDateOperand).getIntValue() * 1000L)), (e1, e2) -> e1));
/*     */ 
/*     */     
/* 253 */     return maxPulldatesPerVdn;
/*     */   }
/*     */ }


/* Location:              C:\kwgo\software\datapull\datapull_lib\lib\datapull.jar!\ca\bell\datapull\remedy\ItsmBroker.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */