/*     */ package ca.bell.datapull.remedy.schema;
/*     */ 
/*     */ import ca.bell.datapull.Context;
/*     */ import ca.bell.datapull.exception.ConfigException;
/*     */ import ca.bell.datapull.exception.RemedyValueException;
/*     */ import ca.bell.datapull.util.IniFile;
/*     */ import com.bmc.arsys.api.ARException;
/*     */ import com.bmc.arsys.api.ARServerUser;
/*     */ import com.bmc.arsys.api.Field;
/*     */ import com.bmc.arsys.api.Value;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BulkLoadSchema
/*     */ {
/*     */   private static String name;
/*     */   
/*     */   public enum SemanticField
/*     */   {
/*  29 */     ABANDONED((String)IniFile.IniToken.FIELD_ABANDONED), ABANDONED_POST_THRESHOLD((String)IniFile.IniToken.FIELD_ABANDONED_POST_THRESHOLD), ABANDONED_WAIT_SEC((String)IniFile.IniToken.FIELD_ABANDONED_WAIT_SEC), ANSWER_WAIT_SEC((String)IniFile.IniToken.FIELD_ANSWER_WAIT_SEC),
/*  30 */     ANSWERED((String)IniFile.IniToken.FIELD_ANSWERED), ANSWERED_HOLD_PAST_THRESHOLD((String)IniFile.IniToken.FIELD_ANSWERED_HOLD_BEYOND_THRESHOLD), ANSWERED_POST_THRESHOLD((String)IniFile.IniToken.FIELD_ANSWERED_POST_THRESHOLD),
/*  31 */     DATE((String)IniFile.IniToken.FIELD_DATE), DROPPED((String)IniFile.IniToken.FIELD_DROPPED),
/*  32 */     HOUR((String)IniFile.IniToken.FIELD_HOUR), INCOMING((String)IniFile.IniToken.FIELD_INCOMING),
/*  33 */     LINK((String)IniFile.IniToken.FIELD_LINK), MAX_WAIT_SEC((String)IniFile.IniToken.FIELD_MAX_WAIT_SEC),
/*  34 */     STATUS((String)IniFile.IniToken.FIELD_STATUS), TALK_SEC((String)IniFile.IniToken.FIELD_TALK_SEC),
/*  35 */     VDN((String)IniFile.IniToken.FIELD_VDN);
/*     */     
/*     */     private IniFile.IniToken iniKey;
/*     */     
/*     */     private String remedyFieldName;
/*     */     
/*     */     SemanticField(IniFile.IniToken iniKey) {
/*  42 */       this.iniKey = iniKey;
/*  43 */       this.remedyFieldName = null;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public FieldInfo getFieldInfo() {
/*  53 */       if (this.remedyFieldName == null) {
/*  54 */         throw new IllegalStateException("Call BulkLoadSchema.init() first");
/*     */       }
/*  56 */       return BulkLoadSchema.getInstance().getFieldInfo(this.remedyFieldName);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Integer getId() {
/*  66 */       if (this.remedyFieldName == null) {
/*  67 */         throw new IllegalStateException("Call BulkLoadSchema.init() first");
/*     */       }
/*  69 */       return BulkLoadSchema.getInstance().getFieldInfo(this.remedyFieldName).getId();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public IniFile.IniToken getIniKey() {
/*  78 */       return this.iniKey;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getRemedyFieldName() {
/*  88 */       if (this.remedyFieldName == null) {
/*  89 */         throw new IllegalStateException("Call BulkLoadSchema.init() first");
/*     */       }
/*     */       
/*  92 */       return this.remedyFieldName;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Value toValue(String input) throws RemedyValueException {
/* 106 */       if (this.remedyFieldName == null) {
/* 107 */         throw new IllegalStateException("Call BulkLoadSchema.init() first");
/*     */       }
/* 109 */       return BulkLoadSchema.getInstance().getFieldInfo(this.remedyFieldName).toValue(input);
/*     */     }
/*     */     
/*     */     private void setRemedyFieldName(String remedyFieldName) {
/* 113 */       this.remedyFieldName = remedyFieldName;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static SemanticField fromName(String remedyFieldName) {
/* 125 */       for (SemanticField sf : values()) {
/* 126 */         if (sf.remedyFieldName == null) {
/* 127 */           throw new IllegalStateException("Call BulkLoadSchema.init() first");
/*     */         }
/* 129 */         if (sf.remedyFieldName.equals(remedyFieldName)) {
/* 130 */           return sf;
/*     */         }
/*     */       } 
/* 133 */       return null;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public enum Status
/*     */   {
/* 141 */     ACTIVE("Active"), INACTIVE("Inactive");
/*     */     
/*     */     private String displayValue;
/*     */     
/*     */     Status(String displayValue) {
/* 146 */       this.displayValue = displayValue;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/* 157 */       return this.displayValue;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static Status fromDisplayValue(String displayValue) {
/* 170 */       if (displayValue == null) {
/* 171 */         return null;
/*     */       }
/*     */       
/* 174 */       for (Status s : values()) {
/* 175 */         if (s.displayValue == null) {
/* 176 */           throw new IllegalStateException("Call BulkLoadSchema.init() first");
/*     */         }
/* 178 */         if (s.displayValue.equals(displayValue)) {
/* 179 */           return s;
/*     */         }
/*     */       } 
/* 182 */       return null;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 188 */   private static BulkLoadSchema theInstance = null;
/*     */   
/*     */   private Map<String, FieldInfo> fields;
/*     */   
/*     */   private BulkLoadSchema() throws ARException, ConfigException {
/* 193 */     this.fields = new HashMap<>();
/*     */     
/* 195 */     Context ctx = Context.getInstance();
/* 196 */     IniFile ini = ctx.getIniFile();
/*     */     
/* 198 */     if (name == null) {
/* 199 */       name = ini.getMandatoryString(IniFile.IniToken.SECTION_BULK_LOAD, IniFile.IniToken.SCHEMA);
/*     */     }
/*     */     
/* 202 */     for (SemanticField sf : SemanticField.values())
/*     */     {
/* 204 */       sf.setRemedyFieldName(ini.getMandatoryString(IniFile.IniToken.SECTION_BULK_LOAD, sf.getIniKey()));
/*     */     }
/*     */     
/* 207 */     ARServerUser session = ctx.getSession();
/* 208 */     for (Field f : session.getListFieldObjects(name)) {
/* 209 */       this.fields.put(f.getName(), new FieldInfo(f));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FieldInfo getFieldInfo(String remedyFieldName) {
/* 222 */     return this.fields.get(remedyFieldName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BulkLoadSchema getInstance() {
/* 232 */     synchronized (BulkLoadSchema.class) {
/* 233 */       if (theInstance == null) {
/* 234 */         throw new IllegalStateException("Call BulkLoadSchema.init() first");
/*     */       }
/*     */     } 
/*     */     
/* 238 */     return theInstance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getName() {
/* 248 */     if (name == null) {
/* 249 */       throw new IllegalStateException("Call BulkLoadSchema.init() first");
/*     */     }
/*     */     
/* 252 */     return name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static BulkLoadSchema init() throws ARException, ConfigException {
/* 266 */     synchronized (BulkLoadSchema.class) {
/* 267 */       if (theInstance == null) {
/* 268 */         theInstance = new BulkLoadSchema();
/*     */       }
/*     */     } 
/*     */     
/* 272 */     return theInstance;
/*     */   }
/*     */ }


/* Location:              C:\kwgo\software\datapull\datapull_lib\lib\datapull.jar!\ca\bell\datapull\remedy\schema\BulkLoadSchema.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */