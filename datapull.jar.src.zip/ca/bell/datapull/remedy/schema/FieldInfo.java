/*     */ package ca.bell.datapull.remedy.schema;
/*     */ 
/*     */ import ca.bell.datapull.exception.RemedyValueException;
/*     */ import ca.bell.datapull.remedy.value.AbstractValueFactory;
/*     */ import ca.bell.datapull.remedy.value.CharValueFactory;
/*     */ import ca.bell.datapull.remedy.value.DateTimeValueFactory;
/*     */ import ca.bell.datapull.remedy.value.IntegerValueFactory;
/*     */ import ca.bell.datapull.remedy.value.NonValueFactory;
/*     */ import ca.bell.datapull.remedy.value.SelectionValueFactory;
/*     */ import com.bmc.arsys.api.CharacterFieldLimit;
/*     */ import com.bmc.arsys.api.EnumItem;
/*     */ import com.bmc.arsys.api.Field;
/*     */ import com.bmc.arsys.api.SelectionFieldLimit;
/*     */ import com.bmc.arsys.api.Value;
/*     */ import java.util.List;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FieldInfo
/*     */ {
/*  34 */   private static Logger logger = Logger.getLogger(FieldInfo.class);
/*     */ 
/*     */ 
/*     */   
/*     */   private Integer id;
/*     */ 
/*     */ 
/*     */   
/*     */   private String name;
/*     */ 
/*     */ 
/*     */   
/*     */   private AbstractValueFactory valueFactory;
/*     */ 
/*     */ 
/*     */   
/*     */   public FieldInfo(Field field) {
/*  51 */     if (field == null) {
/*  52 */       throw new IllegalArgumentException("field must not be null");
/*     */     }
/*     */     
/*  55 */     this.name = field.getName();
/*  56 */     this.id = Integer.valueOf(field.getFieldID());
/*     */     
/*  58 */     if (field instanceof com.bmc.arsys.api.CharacterField) {
/*  59 */       CharacterFieldLimit limit = (CharacterFieldLimit)field.getFieldLimit();
/*  60 */       this.valueFactory = (limit == null) ? (AbstractValueFactory)new CharValueFactory() : (AbstractValueFactory)new CharValueFactory(limit.getMaxLength());
/*  61 */       logger.debug("Init schema [" + field.getForm() + "], field [" + this.name + "], id [" + this.id.toString() + "] of type Character (limit: " + (
/*  62 */           (limit == null) ? "none" : Integer.valueOf(limit.getMaxLength())) + ")");
/*  63 */     } else if (field instanceof com.bmc.arsys.api.SelectionField) {
/*  64 */       SelectionValueFactory vfac = new SelectionValueFactory(field.getForm(), this.name);
/*  65 */       SelectionFieldLimit sfLimit = (SelectionFieldLimit)field.getFieldLimit();
/*  66 */       if (sfLimit != null) {
/*  67 */         List<EnumItem> enumList = sfLimit.getValues();
/*  68 */         for (EnumItem enumItem : enumList) {
/*  69 */           vfac.put(enumItem.getEnumItemName(), Integer.valueOf(enumItem.getEnumItemNumber()));
/*  70 */           logger.debug("Init schema [" + field.getForm() + "], field [" + this.name + "], id [" + this.id.toString() + "] selection [" + enumItem
/*  71 */               .getEnumItemName() + "] index [" + enumItem.getEnumItemNumber() + "]");
/*     */         } 
/*     */       } 
/*     */       
/*  75 */       this.valueFactory = (AbstractValueFactory)vfac;
/*  76 */     } else if (field instanceof com.bmc.arsys.api.DateTimeField) {
/*  77 */       this.valueFactory = (AbstractValueFactory)DateTimeValueFactory.getInstance();
/*  78 */       logger.debug("Init schema [" + field.getForm() + "], field [" + this.name + "], id [" + this.id.toString() + "] of type DateTime");
/*     */     }
/*  80 */     else if (field instanceof com.bmc.arsys.api.IntegerField) {
/*  81 */       this.valueFactory = (AbstractValueFactory)IntegerValueFactory.getInstance();
/*  82 */       logger.debug("Init schema [" + field.getForm() + "], field [" + this.name + "], id [" + this.id.toString() + "] of type Integer");
/*     */     } else {
/*     */       
/*  85 */       logger.debug("Ignoring Init schema [" + field.getForm() + "], field [" + this.name + "], id [" + this.id.toString() + "] of type #" + field
/*  86 */           .getDataType());
/*  87 */       this.valueFactory = (AbstractValueFactory)NonValueFactory.getInstance();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer getId() {
/*  98 */     return this.id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 108 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AbstractValueFactory getValueFactory() {
/* 118 */     return this.valueFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Value toValue(String input) throws RemedyValueException {
/* 132 */     return this.valueFactory.str2Value(input);
/*     */   }
/*     */ }


/* Location:              C:\kwgo\software\datapull\datapull_lib\lib\datapull.jar!\ca\bell\datapull\remedy\schema\FieldInfo.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */