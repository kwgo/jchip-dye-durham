/*    */ package ca.bell.datapull.exception;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConfigException
/*    */   extends ItsmLoadException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public ConfigException() {
/* 13 */     super(ItsmLoadException.Err.CONFIG);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ConfigException(String prefix) {
/* 23 */     super(ItsmLoadException.Err.CONFIG, (prefix == null) ? "" : prefix);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ConfigException(String prefix, Throwable cause) {
/* 35 */     super(ItsmLoadException.Err.CONFIG, prefix, cause);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ConfigException(Throwable cause) {
/* 45 */     super(ItsmLoadException.Err.CONFIG, cause);
/*    */   }
/*    */ }


/* Location:              C:\kwgo\software\datapull\datapull_lib\lib\datapull.jar!\ca\bell\datapull\exception\ConfigException.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */