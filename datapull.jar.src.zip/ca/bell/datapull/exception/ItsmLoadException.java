/*     */ package ca.bell.datapull.exception;
/*     */ 
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ 
/*     */ 
/*     */ public abstract class ItsmLoadException
/*     */   extends Exception
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private int code;
/*     */   
/*     */   public enum Err
/*     */   {
/*  15 */     CONFIG(-1001, "Bad configuration"), DB(-1009, "Database exception"), PARM(-1005, "Bad parameter"),
/*  16 */     REMEDY_VALUE(-1004, "Bad Remedy field value");
/*     */     
/*     */     private int code;
/*     */     
/*     */     private String message;
/*     */     
/*     */     Err(int code, String message) {
/*  23 */       this.code = code;
/*  24 */       this.message = message;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getCode() {
/*  34 */       return this.code;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getMessage() {
/*  43 */       return this.message;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/*  54 */       return "[" + this.code + "]" + this.message;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected ItsmLoadException(Err err) {
/*  63 */     this(err.getCode(), err.getMessage());
/*     */   }
/*     */   
/*     */   protected ItsmLoadException(Err err, String prefix) {
/*  67 */     this(err.getCode(), prefix + ": " + prefix);
/*     */   }
/*     */   
/*     */   protected ItsmLoadException(Err err, String prefix, Throwable cause) {
/*  71 */     this(err.getCode(), prefix + ": " + prefix, cause);
/*     */   }
/*     */   
/*     */   protected ItsmLoadException(Err err, Throwable cause) {
/*  75 */     this(err.getCode(), err.getMessage(), cause);
/*     */   }
/*     */   
/*     */   protected ItsmLoadException(int code, String message) {
/*  79 */     super(message);
/*  80 */     this.code = code;
/*     */   }
/*     */   
/*     */   protected ItsmLoadException(int code, String message, Throwable cause) {
/*  84 */     super(message, cause);
/*  85 */     this.code = code;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String detail() {
/*  95 */     StringWriter sw = new StringWriter();
/*  96 */     printStackTrace(new PrintWriter(sw));
/*  97 */     return sw.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getCode() {
/* 107 */     return this.code;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 118 */     return "[" + this.code + "] " + getMessage();
/*     */   }
/*     */ }


/* Location:              C:\kwgo\software\datapull\datapull_lib\lib\datapull.jar!\ca\bell\datapull\exception\ItsmLoadException.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */