/*    */ package ca.bell.datapull.exception;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ParmException
/*    */   extends ItsmLoadException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public ParmException() {
/* 13 */     super(ItsmLoadException.Err.PARM);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ParmException(String prefix) {
/* 23 */     super(ItsmLoadException.Err.PARM, (prefix == null) ? "" : prefix);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ParmException(String prefix, Throwable cause) {
/* 35 */     super(ItsmLoadException.Err.PARM, prefix, cause);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ParmException(Throwable cause) {
/* 45 */     super(ItsmLoadException.Err.PARM, cause);
/*    */   }
/*    */ }


/* Location:              C:\kwgo\software\datapull\datapull_lib\lib\datapull.jar!\ca\bell\datapull\exception\ParmException.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */