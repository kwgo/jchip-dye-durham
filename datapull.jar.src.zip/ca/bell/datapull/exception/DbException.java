/*    */ package ca.bell.datapull.exception;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DbException
/*    */   extends ItsmLoadException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public DbException() {
/* 13 */     super(ItsmLoadException.Err.DB);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public DbException(String prefix) {
/* 23 */     super(ItsmLoadException.Err.DB, (prefix == null) ? "" : prefix);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public DbException(String prefix, Throwable cause) {
/* 35 */     super(ItsmLoadException.Err.DB, prefix, cause);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public DbException(Throwable cause) {
/* 45 */     super(ItsmLoadException.Err.DB, cause);
/*    */   }
/*    */ }


/* Location:              C:\kwgo\software\datapull\datapull_lib\lib\datapull.jar!\ca\bell\datapull\exception\DbException.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */