/*    */ package ca.bell.datapull.exception;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RemedyValueException
/*    */   extends ItsmLoadException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public RemedyValueException() {
/* 13 */     super(ItsmLoadException.Err.REMEDY_VALUE);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public RemedyValueException(String prefix) {
/* 23 */     super(ItsmLoadException.Err.REMEDY_VALUE, (prefix == null) ? "" : prefix);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public RemedyValueException(String prefix, Throwable cause) {
/* 35 */     super(ItsmLoadException.Err.REMEDY_VALUE, prefix, cause);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public RemedyValueException(Throwable cause) {
/* 45 */     super(ItsmLoadException.Err.REMEDY_VALUE, cause);
/*    */   }
/*    */ }


/* Location:              C:\kwgo\software\datapull\datapull_lib\lib\datapull.jar!\ca\bell\datapull\exception\RemedyValueException.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */