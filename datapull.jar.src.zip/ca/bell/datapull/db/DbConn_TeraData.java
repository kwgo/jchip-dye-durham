/*     */ package ca.bell.datapull.db;
/*     */ 
/*     */ import ca.bell.datapull.exception.ConfigException;
/*     */ import ca.bell.datapull.exception.DbException;
/*     */ import ca.bell.datapull.util.IniFile;
/*     */ import java.sql.Connection;
/*     */ import java.sql.DriverManager;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.time.LocalDateTime;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DbConn_TeraData
/*     */ {
/*     */   public static final int SLSD_HOLD_SEC = 30;
/*     */   private static IniFile iniFile;
/*  30 */   private static Logger logger = Logger.getLogger(DbConn_TeraData.class);
/*     */   
/*  32 */   private static DbConn_TeraData theInstance = null;
/*     */ 
/*     */ 
/*     */   
/*     */   private Connection conn;
/*     */ 
/*     */ 
/*     */   
/*     */   private DbConn_TeraData() throws DbException, ConfigException {
/*  41 */     if (iniFile == null) {
/*  42 */       throw new IllegalStateException("Call Context.init() first");
/*     */     }
/*     */     
/*  45 */     String host = iniFile.getMandatoryString(IniFile.IniToken.SECTION_DATABASE, IniFile.IniToken.HOST_TERADATA);
/*  46 */     int port = iniFile.getInteger(IniFile.IniToken.SECTION_DATABASE, IniFile.IniToken.PORT_TERADATA).intValue();
/*  47 */     String user = iniFile.getString(IniFile.IniToken.SECTION_DATABASE, IniFile.IniToken.USER_TERADATA);
/*  48 */     String password = iniFile.getString(IniFile.IniToken.SECTION_DATABASE, IniFile.IniToken.PASSWORD_TERADATA);
/*  49 */     String teradata_db = iniFile.getString(IniFile.IniToken.SECTION_DATABASE, IniFile.IniToken.TERADATA_DB);
/*     */     
/*  51 */     for (int i = 0;; i++) {
/*     */       try {
/*  53 */         this.conn = DriverManager.getConnection(
/*  54 */             String.format("jdbc:teradata://%s/DATABASE=%s,DBS_PORT=%d", new Object[] { host, teradata_db, Integer.valueOf(port) }), user, password);
/*     */         
/*     */         break;
/*  57 */       } catch (SQLException x) {
/*  58 */         if (i > 2) {
/*  59 */           throw new DbException(x.getMessage());
/*     */         }
/*     */         try {
/*  62 */           logger.warn(String.format("TeraDB Database connection attempt #%d failed; waiting 10 sec and retrying", new Object[] {
/*  63 */                   Integer.valueOf(i + 1) }));
/*  64 */           logger.warn(x.getMessage());
/*  65 */           Thread.sleep(10000L);
/*  66 */         } catch (InterruptedException interruptedException) {}
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<VdnRec> getVdnRecs(String sql) throws DbException {
/*  74 */     PreparedStatement stmt = null;
/*  75 */     ResultSet rs = null;
/*  76 */     List<VdnRec> vdnRecs = new ArrayList<>();
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*  81 */       stmt = this.conn.prepareStatement(sql);
/*     */       
/*  83 */       rs = stmt.executeQuery();
/*     */       
/*  85 */       while (rs.next()) {
/*  86 */         Calendar cal = Calendar.getInstance();
/*  87 */         cal.setTime(new Date(rs.getDate(2).getTime()));
/*  88 */         int month = cal.get(2);
/*  89 */         int day = cal.get(5);
/*  90 */         int year = cal.get(1);
/*  91 */         LocalDateTime ldt = LocalDateTime.of(year, month + 1, day, 0, 0, 0);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 103 */         VdnRec vdnRec = new VdnRec(ldt, Integer.parseInt(rs.getString(3)), rs.getString(1), rs.getInt(4), rs.getInt(6), rs.getInt(8), rs.getInt(7), rs.getInt(9), rs.getInt(4) - rs.getInt(6), rs.getInt(5), rs.getInt(11), rs.getInt(12), rs.getInt(10));
/*     */         
/* 105 */         vdnRecs.add(vdnRec);
/*     */       } 
/*     */ 
/*     */       
/* 109 */       stmt.close();
/* 110 */       stmt = null;
/* 111 */       rs.close();
/* 112 */       rs = null;
/* 113 */     } catch (SQLException x) {
/* 114 */       throw new DbException("SQL exception on data pull: " + x.getMessage());
/*     */     } finally {
/* 116 */       if (stmt != null) {
/*     */         try {
/* 118 */           stmt.close();
/* 119 */         } catch (SQLException x) {
/* 120 */           logger.error("Error closing statement: " + x.getMessage());
/*     */         } 
/*     */       }
/* 123 */       if (rs != null) {
/*     */         try {
/* 125 */           rs.close();
/* 126 */         } catch (SQLException x) {
/* 127 */           logger.error("Error closing result set: " + x.getMessage());
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 132 */     return vdnRecs;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void shutDown() {
/* 139 */     if (this.conn != null) {
/*     */       try {
/* 141 */         this.conn.close();
/* 142 */         logger.info("Teradata db connection closed.");
/* 143 */       } catch (SQLException x) {
/*     */         
/* 145 */         logger.error("Exception on DB connection shutdown: " + x.getMessage());
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DbConn_TeraData getInstance() {
/* 157 */     synchronized (DbConn_TeraData.class) {
/* 158 */       if (theInstance == null) {
/* 159 */         throw new IllegalStateException("Call Context.init() first");
/*     */       }
/*     */     } 
/*     */     
/* 163 */     return theInstance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized void init(IniFile iniFile) throws DbException, ConfigException {
/* 173 */     if (iniFile == null) {
/* 174 */       throw new IllegalArgumentException("iniFile must not be null");
/*     */     }
/* 176 */     DbConn_TeraData.iniFile = iniFile;
/* 177 */     theInstance = new DbConn_TeraData();
/*     */   }
/*     */ }


/* Location:              C:\kwgo\software\datapull\datapull_lib\lib\datapull.jar!\ca\bell\datapull\db\DbConn_TeraData.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */