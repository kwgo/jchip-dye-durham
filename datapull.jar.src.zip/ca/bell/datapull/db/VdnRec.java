/*     */ package ca.bell.datapull.db;
/*     */ 
/*     */ import java.time.LocalDateTime;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class VdnRec
/*     */ {
/*     */   private int abandoned;
/*     */   private int abandonedPostThreshold;
/*     */   private int abandonedWaitSec;
/*     */   private int ansHoldPastThreshold;
/*     */   private int answered;
/*     */   private int answeredPostThreshold;
/*     */   private int answerWaitSec;
/*     */   private int dropped;
/*     */   private int hour;
/*     */   private int incoming;
/*     */   private LocalDateTime localDateHour;
/*     */   private int maxWaitSec;
/*     */   private int talkSec;
/*     */   private String vdn;
/*     */   
/*     */   public VdnRec(LocalDateTime localDateTime, int hour, String vdn, int incoming, int answered, int abandoned, int answeredPostThreshold, int abandonedPostThreshold, int dropped, int answerWaitSec, int maxWaitSec, int talkSec, int abandonedWaitSec) {
/*  69 */     this.localDateHour = localDateTime;
/*  70 */     this.hour = hour;
/*  71 */     this.vdn = vdn;
/*  72 */     this.incoming = incoming;
/*  73 */     this.answered = answered;
/*  74 */     this.abandoned = abandoned;
/*  75 */     this.answeredPostThreshold = answeredPostThreshold;
/*  76 */     this.abandonedPostThreshold = abandonedPostThreshold;
/*  77 */     this.dropped = dropped;
/*  78 */     this.answerWaitSec = answerWaitSec;
/*  79 */     this.maxWaitSec = maxWaitSec;
/*  80 */     this.talkSec = talkSec;
/*  81 */     this.abandonedWaitSec = abandonedWaitSec;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getAbandoned() {
/*  91 */     return this.abandoned;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getAbandonedPostThreshold() {
/* 101 */     return this.abandonedPostThreshold;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getAbandonedWaitSec() {
/* 111 */     return this.abandonedWaitSec;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getAnsHoldPastThreshold() {
/* 121 */     return this.ansHoldPastThreshold;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getAnswered() {
/* 131 */     return this.answered;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getAnsweredPostThreshold() {
/* 141 */     return this.answeredPostThreshold;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getAnswerWaitSec() {
/* 151 */     return this.answerWaitSec;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getDropped() {
/* 161 */     return this.dropped;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getHour() {
/* 171 */     return this.hour;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getIncoming() {
/* 181 */     return this.incoming;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LocalDateTime getLocalDateHour() {
/* 191 */     return this.localDateHour;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaxWaitSec() {
/* 201 */     return this.maxWaitSec;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTalkSec() {
/* 211 */     return this.talkSec;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getVdn() {
/* 221 */     return this.vdn;
/*     */   }
/*     */   
/*     */   public void setHour(int hour) {
/* 225 */     this.hour = hour;
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 230 */     return "VdnRec [localDateHour=" + this.localDateHour + ", vdn=" + this.vdn + ", incoming=" + this.incoming + ", answered=" + this.answered + ", abandoned=" + this.abandoned + ", answeredPostThreshold=" + this.answeredPostThreshold + ", abandonedPostThreshold=" + this.abandonedPostThreshold + ", dropped=" + this.dropped + ", answerWaitSec=" + this.answerWaitSec + ", maxWaitSec=" + this.maxWaitSec + ", talkSec=" + this.talkSec + ", abandonedWaitSec=" + this.abandonedWaitSec + ", ansHoldPastThreshold=" + this.ansHoldPastThreshold + ", hour=" + this.hour + "]";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setAbandoned(int abandoned) {
/* 238 */     this.abandoned = abandoned;
/*     */   }
/*     */   
/*     */   private void setAbandonedPostThreshold(int abandonedPostThreshold) {
/* 242 */     this.abandonedPostThreshold = abandonedPostThreshold;
/*     */   }
/*     */   
/*     */   private void setAbandonedWaitSec(int abandonedWaitSec) {
/* 246 */     this.abandonedWaitSec = abandonedWaitSec;
/*     */   }
/*     */   
/*     */   private void setAnsHoldPastThreshold(int ansHoldPastThreshold) {
/* 250 */     this.ansHoldPastThreshold = ansHoldPastThreshold;
/*     */   }
/*     */   
/*     */   private void setAnswered(int answered) {
/* 254 */     this.answered = answered;
/*     */   }
/*     */   
/*     */   private void setAnsweredPostThreshold(int answeredPostThreshold) {
/* 258 */     this.answeredPostThreshold = answeredPostThreshold;
/*     */   }
/*     */   
/*     */   private void setAnswerWaitSec(int answerWaitSec) {
/* 262 */     this.answerWaitSec = answerWaitSec;
/*     */   }
/*     */   
/*     */   private void setDropped(int dropped) {
/* 266 */     this.dropped = dropped;
/*     */   }
/*     */   
/*     */   private void setIncoming(int incoming) {
/* 270 */     this.incoming = incoming;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setLocalDateHour(LocalDateTime localDateHour) {
/* 277 */     this.localDateHour = localDateHour;
/*     */   }
/*     */   
/*     */   private void setMaxWaitSec(int maxWaitSec) {
/* 281 */     this.maxWaitSec = maxWaitSec;
/*     */   }
/*     */   
/*     */   private void setTalkSec(int talkSec) {
/* 285 */     this.talkSec = talkSec;
/*     */   }
/*     */   
/*     */   private void setVdn(String vdn) {
/* 289 */     this.vdn = vdn;
/*     */   }
/*     */ }


/* Location:              C:\kwgo\software\datapull\datapull_lib\lib\datapull.jar!\ca\bell\datapull\db\VdnRec.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */