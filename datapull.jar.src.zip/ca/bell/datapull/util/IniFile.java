/*     */ package ca.bell.datapull.util;
/*     */ 
/*     */ import ca.bell.datapull.exception.ConfigException;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import java.util.TreeMap;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IniFile
/*     */ {
/*     */   public enum IniToken
/*     */   {
/*  27 */     CONFIG("config"), CONNECT("connect", "1"), DIR_SERIAL("dir.serial"), FIELD_ABANDONED("field.abandoned"),
/*  28 */     FIELD_ABANDONED_POST_THRESHOLD("field.abandoned.post.threshold"), FIELD_ABANDONED_WAIT_SEC("field.abandoned.wait.sec"), FIELD_ANSWER_WAIT_SEC("field.answer.wait.sec"), FIELD_ANSWERED("field.answered"),
/*  29 */     FIELD_ANSWERED_HOLD_BEYOND_THRESHOLD("field.answered.hold.beyond.threshold"), FIELD_ANSWERED_POST_THRESHOLD("field.answered.post.threshold"), FIELD_DATE("field.date"),
/*  30 */     FIELD_DROPPED("field.dropped"), FIELD_HOUR("field.hour"), FIELD_INCOMING("field.incoming"),
/*  31 */     FIELD_LINK("field.link"),
/*     */     
/*  33 */     FIELD_MAX_WAIT_SEC("field.max.wait.sec"), FIELD_STATUS("field.status"), FIELD_TALK_SEC("field.talk.sec"),
/*     */     
/*  35 */     FIELD_VDN("field.vdn"), HOST("host"), HOST_TERADATA("host_teradata"),
/*  36 */     INFORMIX_SERVER("informix.server"), LIST_VDN("list.vdn"), PASSWORD("password"), PASSWORD_TERADATA("password_teradata"),
/*  37 */     PORT("port"), PORT_TERADATA("port_teradata"), PREFIX_LINK("prefix.link", "CallData"),
/*  38 */     REMEDY_PORT("port", "11000"), RETENTION_SERIAL_DAYS("retention.serial.days", "0"),
/*  39 */     SCHEMA("schema"), SECTION_BULK_LOAD("Bulk Load"),
/*  40 */     SECTION_DATABASE("Database"), SECTION_LOG4J("Log4j"),
/*  41 */     SECTION_REMEDY("Remedy"), SERVER("server"),
/*  42 */     TERADATA_DB("teradata_db"),
/*     */     
/*  44 */     USER("user"), USER_TERADATA("user_teradata");
/*     */ 
/*     */     
/*     */     private String dfault;
/*     */ 
/*     */     
/*     */     private String token;
/*     */ 
/*     */ 
/*     */     
/*     */     IniToken(String token, String dfault) {
/*  55 */       this.token = token;
/*  56 */       this.dfault = dfault;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getDefault() {
/*  65 */       return this.dfault;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String toString() {
/*  76 */       return this.token;
/*     */     }
/*     */   }
/*     */   
/*  80 */   private static final Pattern KEY_VALUE = Pattern.compile("^\\s*(.*?)\\s*=\\s*(.*?)\\s*$");
/*     */ 
/*     */ 
/*     */   
/*     */   private String iniPath;
/*     */ 
/*     */ 
/*     */   
/*     */   private TreeMap<String, TreeMap<String, String>> sections;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IniFile(File f) throws ConfigException {
/*  94 */     if (f == null) {
/*  95 */       throw new IllegalArgumentException("f must not be null");
/*     */     }
/*     */     
/*  98 */     this.iniPath = f.getAbsolutePath();
/*  99 */     readFile(f);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IniFile(String fname) throws ConfigException {
/* 110 */     this(new File(fname));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Boolean getBoolean(IniToken sec, IniToken key) throws ConfigException {
/* 128 */     if (sec == null || key == null) {
/* 129 */       throw new IllegalArgumentException("sec, key must not be null");
/*     */     }
/*     */     
/* 132 */     String rv = getString(sec, key);
/* 133 */     if (rv == null) {
/* 134 */       return null;
/*     */     }
/*     */     
/* 137 */     Set<String> truthy = new HashSet<>(Arrays.asList(new String[] { "1", "true", "yes", "on" }));
/* 138 */     return Boolean.valueOf(truthy.contains(rv.toLowerCase()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getIniPath() {
/* 148 */     return this.iniPath;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer getInteger(IniToken sec, IniToken key) throws ConfigException {
/* 166 */     if (sec == null || key == null) {
/* 167 */       throw new IllegalArgumentException("sec, key must not be null");
/*     */     }
/*     */     
/* 170 */     String rv = getString(sec, key);
/*     */     try {
/* 172 */       return Integer.valueOf(Integer.parseInt(rv));
/* 173 */     } catch (NumberFormatException x) {
/* 174 */       throw new ConfigException("In configuration file [" + this.iniPath + "], in section [" + sec + "], value for key [" + key + "] must be an integer");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<String> getKeys(IniToken sec) {
/* 188 */     if (sec == null) {
/* 189 */       throw new IllegalArgumentException("sec must not be null");
/*     */     }
/*     */     
/* 192 */     TreeMap<String, String> props = this.sections.get(sec.toString());
/* 193 */     return (props == null) ? null : props.keySet().iterator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Boolean getMandatoryBoolean(IniToken sec, IniToken key) throws ConfigException {
/* 211 */     if (sec == null || key == null) {
/* 212 */       throw new IllegalArgumentException("sec, key must not be null");
/*     */     }
/*     */     
/* 215 */     String rv = getString(sec, key);
/* 216 */     if (rv == null) {
/* 217 */       throw new ConfigException("In configuration file [" + this.iniPath + "], in section [" + sec + "], mandatory value for key [" + key + "] is missing");
/*     */     }
/*     */ 
/*     */     
/* 221 */     Set<String> truthy = new HashSet<>(Arrays.asList(new String[] { "1", "true", "yes", "on" }));
/* 222 */     return Boolean.valueOf(truthy.contains(rv.toLowerCase()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Integer getMandatoryInteger(IniToken sec, IniToken key) throws ConfigException {
/* 240 */     Integer rv = getInteger(sec, key);
/* 241 */     if (rv == null) {
/* 242 */       throw new ConfigException("In configuration file [" + this.iniPath + "], in section [" + sec + "], mandatory value for key [" + key + "] is missing");
/*     */     }
/*     */ 
/*     */     
/* 246 */     return rv;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getMandatoryString(IniToken sec, IniToken key) throws ConfigException {
/* 264 */     String rv = getString(sec, key);
/* 265 */     if (rv == null) {
/* 266 */       throw new ConfigException("In configuration file [" + this.iniPath + "], in section [" + sec + "], mandatory value for key [" + key + "] is missing");
/*     */     }
/*     */ 
/*     */     
/* 270 */     return rv;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Iterator<String> getSections() {
/* 280 */     if (this.sections.keySet() == null) {
/* 281 */       return null;
/*     */     }
/*     */     
/* 284 */     return this.sections.keySet().iterator();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getString(IniToken sec, IniToken key) {
/* 301 */     if (sec == null || key == null) {
/* 302 */       throw new IllegalArgumentException("sec, key must not be null");
/*     */     }
/*     */     
/* 305 */     TreeMap<String, String> props = this.sections.get(sec.toString());
/* 306 */     if (props == null) {
/* 307 */       return null;
/*     */     }
/* 309 */     String rv = props.get(key.toString());
/* 310 */     return (rv == null) ? key.getDefault() : rv;
/*     */   }
/*     */   
/*     */   private void readFile(File f) throws ConfigException {
/*     */     try {
/* 315 */       FileInputStream fileStream = new FileInputStream(f);
/* 316 */       InputStreamReader inStream = new InputStreamReader(fileStream, Charset.forName("UTF-8"));
/* 317 */       BufferedReader reader = new BufferedReader(inStream);
/*     */       
/* 319 */       this.sections = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
/* 320 */       String curSec = null;
/*     */       
/*     */       String line;
/* 323 */       while ((line = reader.readLine()) != null) {
/*     */         
/* 325 */         String trimmed = line.trim();
/* 326 */         if (trimmed.length() == 0 || trimmed.startsWith("#") || trimmed.startsWith(";")) {
/*     */           continue;
/*     */         }
/*     */ 
/*     */         
/* 331 */         if (trimmed.startsWith("[")) {
/*     */           
/* 333 */           if (!trimmed.endsWith("]") || trimmed.indexOf("]") != trimmed.length() - 1) {
/* 334 */             curSec = null;
/*     */             
/*     */             continue;
/*     */           } 
/*     */           
/* 339 */           curSec = trimmed.substring(1, trimmed.length() - 1).trim();
/*     */           
/*     */           continue;
/*     */         } 
/*     */         
/* 344 */         if (curSec == null) {
/*     */           continue;
/*     */         }
/*     */         
/* 348 */         TreeMap<String, String> props = this.sections.get(curSec);
/* 349 */         if (props == null) {
/* 350 */           props = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
/* 351 */           this.sections.put(curSec, props);
/*     */         } 
/*     */         
/* 354 */         Matcher m = KEY_VALUE.matcher(line);
/* 355 */         if (m.matches()) {
/* 356 */           props.put(m.group(1), m.group(2));
/*     */         }
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 362 */       reader.close();
/* 363 */     } catch (IOException x) {
/* 364 */       throw new ConfigException(x.getMessage(), x);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\kwgo\software\datapull\datapull_lib\lib\datapull.jar!\ca\bell\datapul\\util\IniFile.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */