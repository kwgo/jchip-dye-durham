/*    */ package ca.bell.datapull.util;
/*    */ 
/*    */ import ca.bell.datapull.db.DbConn_TeraData;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DbShutdown_TeraData
/*    */ {
/* 11 */   private static Logger logger = Logger.getLogger(DbShutdown_TeraData.class);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void onShutdownHook(final DbConn_TeraData dbConn) {
/* 20 */     if (dbConn == null) {
/*    */       return;
/*    */     }
/*    */     
/* 24 */     Runtime.getRuntime().addShutdownHook(new Thread(new Runnable()
/*    */           {
/*    */             public void run() {
/* 27 */               dbConn.shutDown();
/* 28 */               DbShutdown_TeraData.logger.info("Shut down TeraDatabase database connection.");
/*    */             }
/*    */           }));
/*    */   }
/*    */ }


/* Location:              C:\kwgo\software\datapull\datapull_lib\lib\datapull.jar!\ca\bell\datapul\\util\DbShutdown_TeraData.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */