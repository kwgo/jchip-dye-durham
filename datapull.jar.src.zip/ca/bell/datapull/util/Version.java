/*    */ package ca.bell.datapull.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Version
/*    */ {
/*    */   public static String getVersion() {
/* 14 */     Package pkg = Version.class.getPackage();
/* 15 */     return "Version: " + pkg.getImplementationVersion();
/*    */   }
/*    */ }


/* Location:              C:\kwgo\software\datapull\datapull_lib\lib\datapull.jar!\ca\bell\datapul\\util\Version.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */