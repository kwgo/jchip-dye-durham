/*    */ package ca.bell.datapull.util;
/*    */ 
/*    */ import com.bmc.arsys.api.ARServerUser;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RemedyLogout
/*    */ {
/* 11 */   private static Logger logger = Logger.getLogger(RemedyLogout.class);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static void onShutdownHook(final ARServerUser session) {
/* 20 */     if (session == null) {
/*    */       return;
/*    */     }
/*    */     
/* 24 */     Runtime.getRuntime().addShutdownHook(new Thread(new Runnable()
/*    */           {
/*    */             public void run() {
/* 27 */               if (session != null) {
/* 28 */                 session.logout();
/* 29 */                 RemedyLogout.logger.info("Logged out user [" + session.getUser() + "] from ITSM");
/*    */               } 
/*    */             }
/*    */           }));
/*    */   }
/*    */ }


/* Location:              C:\kwgo\software\datapull\datapull_lib\lib\datapull.jar!\ca\bell\datapul\\util\RemedyLogout.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */